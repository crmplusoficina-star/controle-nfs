'use client';

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useAuth } from '@/lib/auth-context';
import { motion, AnimatePresence } from 'motion/react';
import Image from 'next/image';
import { 
  Zap, 
  Camera, 
  Search, 
  Package, 
  User, 
  FileCheck, 
  X, 
  ChevronRight, 
  CheckCircle2,
  AlertTriangle,
  History,
  Scan,
  HardHat,
  Trophy,
  ArrowRight,
  ClipboardList
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import confetti from 'canvas-confetti';
import { uploadBase64 } from '@/lib/storage';

// Fora do componente — para adicionar novos avatares, só incluir o nome aqui
const AVATAR_NAMES = ['1','2','3','4','5','6','7','8'];

const staticAvatarsList = AVATAR_NAMES.map(name => ({
  id: name,
  url: `https://pub-a347bc4e6808498fbcc0dd6c03a62355.r2.dev/ferramentaria/avatares/${name}.png`,
  category: 'Avatar',
}));

export default function FerramentariaPagina() {
  const { user, updateUser } = useAuth();
  const [activeScreen, setActiveScreen] = useState<'main' | 'borrow' | 'profile' | 'cautela' | 'stock'>('main');
  const [isCameraOpen, setCameraOpen] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isChangingAvatar, setIsChangingAvatar] = useState(false);
  const [avatarSeed, setAvatarSeed] = useState(staticAvatarsList[0]?.url || '');
  const [avatarsList, setAvatarsList] = useState(staticAvatarsList);
  const videoRef = useRef<HTMLVideoElement>(null);
  
  const [pendingAudit, setPendingAudit] = useState<any | null>(null);
  const [isSigningPending, setIsSigningPending] = useState(false);

  const fetchPendingAudit = useCallback(async () => {
    if (!user?.registration) return;
    const reg = String(user.registration || "").trim();

    const { data, error } = await supabase
      .from('cautelia_audits')
      .select('*, cautelia_audit_items(*, cautelia_standard_tools(*), tools:stock_tool_id(*))')
      .eq('user_id', reg)
      .eq('status', 'pending')
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (!error && data) {
      setPendingAudit(data);
    } else {
      setPendingAudit(null);
    }
  }, [user]);

  useEffect(() => {
    const init = async () => {
      await fetchPendingAudit();
    };
    init();
  }, [fetchPendingAudit]);

  const handleAction = (screen: any) => {
    setActiveScreen(screen);
    if (screen === 'stock') fetchStock();
    if (screen === 'profile') fetchUserProfile();
    if (screen === 'cautela') fetchCautelaList();
  };

  const initCamera = async () => {
    setCameraOpen(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error("Câmera não permitida:", err);
      setCameraOpen(false);
    }
  };

  const stopCamera = () => {
    if (videoRef.current?.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
      tracks.forEach(track => track.stop());
    }
    setCameraOpen(false);
  };

  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [detectedTools, setDetectedTools] = useState<any[]>([]);
  const [selectedTools, setSelectedTools] = useState<any[]>([]);
  const [borrowType, setBorrowType] = useState<'loan' | 'caution'>('loan');
  const [stockTools, setStockTools] = useState<any[]>([]);
  const [userTools, setUserTools] = useState<any[]>([]);
  const [cautelaList, setCautelaList] = useState<any[]>([]);
  const [branches, setBranches] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [borrowSignature, setBorrowSignature] = useState<string | null>(null);
  const [manualSearchTerm, setManualSearchTerm] = useState('');
  const [selectedBranchId, setSelectedBranchId] = useState<string>('');
  const [isManualSearch, setIsManualSearch] = useState(false);
  const borrowCanvasRef = useRef<HTMLCanvasElement>(null);
  
  // Game stats

  useEffect(() => {
    const fetchBranches = async () => {
      const { data } = await supabase.from('branches').select('*').order('name');
      setBranches(data || []);
      if (user?.branch_id) setSelectedBranchId(user.branch_id);
      else if (data && data.length > 0) setSelectedBranchId(data[0].id);
    };
    fetchBranches();
  }, [user]);

  const searchManualTools = async (term: string, branchId: string) => {
    if (!branchId) return;
    setIsLoading(true);
    let query = supabase.from('tools').select('*').eq('branch_id', branchId);
    if (term) {
      query = query.or(`name.ilike.%${term}%,code.ilike.%${term}%`);
    }
    const { data } = await query.limit(10);
    setDetectedTools(data || []);
    setIsLoading(false);
  };

  const analyzeToolImage = async (base64: string) => {
    if (!base64 || !selectedBranchId) return;
    setIsAnalyzing(true);
    try {
      // 1. Fetch current catalog for this branch to guide the AI
      const { data: catalog } = await supabase
        .from('tools')
        .select('id, name, code')
        .eq('branch_id', selectedBranchId);

      const catalogList = (catalog || []).map(t => `- ${t.name} [CÓDIGO: ${t.code}]`).join('\n');
      
      const prompt = `Aja como um especialista em inventário industrial. Analise a imagem e identifique TODAS as ferramentas de manutenção industrial visíveis que correspondam ao catálogo abaixo.
Retorne um objeto JSON com um array chamado "tools". Cada item do array deve ter o campo "toolName" (exatamente como no catálogo) e "toolCode" (como no catálogo).
Se houver ferramentas na imagem que NÃO estão na lista, identifique-as pelo nome genérico mais provável da lista.
Ignore o fundo, mãos ou objetos não industriais. 

LISTA DE FERRAMENTAS NO CATÁLOGO:
${catalogList || 'Nenhuma ferramenta cadastrada ainda.'}

ESTRUTURA DE RESPOSTA:
{ 
  "tools": [
    { "toolName": "NOME_DO_CATÁLOGO", "toolCode": "CÓDIGO_DO_CATÁLOGO", "confidence": 95 },
    ...
  ] 
}`;
      
      const response = await fetch('/api/ai/extract', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ image: base64, prompt })
      });

      if (!response.ok) throw new Error('API request failed');
      const data = await response.json();
      const detectedList = data.tools || [];
      
      console.log("AXEL Detectou:", detectedList.length, "itens");
      
      const newMatches: any[] = [];

      for (const item of detectedList) {
        const { toolName, toolCode } = item;
        let searchResult: any = null;
        
        // Priority 1: Match by Code
        if (toolCode) {
          const { data: codeMatch } = await supabase
            .from('tools')
            .select('*')
            .eq('branch_id', selectedBranchId)
            .eq('code', toolCode);
          if (codeMatch && codeMatch.length > 0) searchResult = codeMatch[0];
        }

        // Priority 2: Keyword search for better matching
        if (!searchResult && toolName) {
          const cleanName = toolName.trim().replace(/[^\w\sÀ-ÿ]/gi, '');
          const keywords = cleanName.split(/\s+/).filter((k: string) => k.length > 2);
          
          if (keywords.length > 0) {
            // Try to match using keywords
            const { data: keywordMatch } = await supabase
              .from('tools')
              .select('*')
              .eq('branch_id', selectedBranchId)
              .or(keywords.map((k: string) => `name.ilike.%${k}%`).join(','));
            
            if (keywordMatch && keywordMatch.length > 0) {
              // Prefer exact match if possible
              const exact = keywordMatch.find(t => t.name.toLowerCase() === toolName.toLowerCase());
              searchResult = exact || keywordMatch[0];
            }
          }
        }

        // Priority 3: Fallback simple ilike
        if (!searchResult && toolName) {
          const { data: nameMatch } = await supabase
            .from('tools')
            .select('*')
            .eq('branch_id', selectedBranchId)
            .ilike('name', `%${toolName}%`);
          if (nameMatch && nameMatch.length > 0) searchResult = nameMatch[0];
        }

        if (searchResult) {
          newMatches.push(searchResult);
        }
      }
      
      if (newMatches.length > 0) {
        setDetectedTools(newMatches);
        setIsManualSearch(false);
        setSelectedTools(prev => {
          const onlyNew = newMatches.filter(nm => !prev.find(st => st.id === nm.id));
          return [...prev, ...onlyNew];
        });
        confetti();
      } else {
        setDetectedTools([]);
        setIsManualSearch(true);
      }
    } catch (err) {
      console.error("Erro na análise do AXEL:", err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const takePhoto = async () => {
    const canvas = document.createElement('canvas');
    if (videoRef.current) {
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      const ctx = canvas.getContext('2d');
      ctx?.drawImage(videoRef.current, 0, 0);
      const base64 = canvas.toDataURL('image/jpeg');
      setCapturedImage(base64);
      stopCamera();
      await analyzeToolImage(base64);
    }
  };

  const fetchStock = async () => {
    setIsLoading(true);
    const { data } = await supabase.from('tools').select('*');
    setStockTools(data || []);
    setIsLoading(false);
  };

  const fetchUserProfile = async () => {
    if (!user || !user.registration) return;
    setIsLoading(true);
    const reg = String(user.registration || "").trim();
    
    try {
      const [cautelasResp, reportsResp, transResp] = await Promise.all([
        supabase
          .from('cautelas')
          .select('*, tools(*)')
          .eq('user_id', reg),
        supabase
          .from('cautelia_reports')
          .select('*, cautelia_standard_tools(*)')
          .eq('user_id', reg),
        supabase
          .from('transactions')
          .select('*, tools(*)')
          .eq('user_id', reg)
          .in('status', ['active', 'confirmed'])
      ]);
      
      const cautelasData = cautelasResp.data || [];
      const reports = reportsResp.data || [];
      const transData = transResp.data || [];

      const toolMap = new Map();

      // 1. Add from standard reports
      reports.forEach(r => {
        if (r.cautelia_standard_tools) {
          toolMap.set(`std-${r.tool_id}`, {
            id: r.id,
            name: r.cautelia_standard_tools.name,
            image: null,
            date: r.last_check || r.created_at,
            type: 'standard',
            tool_id: r.tool_id
          });
        }
      });

      // 2. Add from cautelas (Big tools)
      cautelasData.forEach(c => {
        const tipo = String(c.type || '').toLowerCase().trim();
        const isLoan = tipo === 'loan' || tipo === 'emprestimo' || tipo === 'empréstimo' || tipo === 'borrow' || (c.obs || '').toLowerCase().includes('emprestado');
        
        if (c.tools) {
          toolMap.set(`big-${c.tool_id}`, {
            id: c.id,
            name: c.tools.name,
            image: c.tools.image_url,
            date: c.last_check || c.created_at,
            type: 'big',
            tool_id: c.tool_id,
            code: c.tools.code,
            isLoan: isLoan
          });
        }
      });

      // 3. Fallback/Complement from transactions (Active items)
      transData.forEach(t => {
        const tipo = String(t.type || '').toLowerCase().trim();
        const isLoan = tipo === 'loan' || tipo === 'emprestimo' || tipo === 'empréstimo' || tipo === 'borrow' || (t.obs || '').toLowerCase().includes('emprestado');

        if (t.tools && !toolMap.has(`big-${t.tool_id}`)) {
          toolMap.set(`big-${t.tool_id}`, {
            id: t.id,
            name: t.tools.name,
            image: t.tools.image_url,
            date: t.created_at,
            type: 'big',
            tool_id: t.tool_id,
            code: t.tools.code,
            isLoan: isLoan
          });
        }
      });

      setUserTools(Array.from(toolMap.values()).filter(t => t.type !== 'standard'));
    } catch (err) {
      console.error("Error fetching user profile tools:", err);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchCautelaList = async () => {
    if (!user || !user.registration) return;
    setIsLoading(true);
    const reg = String(user.registration || "").trim();
    
    const [reportsResp, cautelasResp] = await Promise.all([
      supabase
        .from('cautelia_reports')
        .select('*, cautelia_standard_tools(*)')
        .eq('user_id', reg),
      supabase
        .from('cautelas')
        .select('*, tools(*)')
        .eq('user_id', reg)
    ]);

    const reports = reportsResp.data || [];
    const allCautelas = cautelasResp.data || [];
    
    // Filtro Inverso: Remove apenas o que for comprovadamente empréstimo
    const bigCautelas = allCautelas.filter(c => {
      const tipo = String(c.type || '').toLowerCase().trim();
      const isLoan = tipo === 'loan' || tipo === 'emprestimo' || tipo === 'empréstimo' || tipo === 'borrow';
      return !isLoan;
    });

    const toolMap = new Map();

    reports.forEach((report) => {
      if (report.cautelia_standard_tools) {
        toolMap.set(report.tool_id, {
          id: report.tool_id,
          tool_id: report.tool_id,
          name: report.cautelia_standard_tools?.name,
          category: report.cautelia_standard_tools?.category || "PADRÃO",
          status: report.status || "ok",
          last_check: report.last_check,
          type: "standard",
        });
      }
    });

    bigCautelas.forEach((c) => {
      const tipo = String(c.type || '').toLowerCase().trim();
      const isLoan = tipo === 'loan' || tipo === 'emprestimo' || tipo === 'empréstimo' || tipo === 'borrow';
      
      if (c.tools && !isLoan) {
        toolMap.set(c.tool_id, {
          id: c.tool_id,
          tool_id: c.tool_id,
          name: c.tools?.name,
          category: "GRANDE PORTE",
          status: c.status || "ok",
          last_check: c.last_check,
          type: "big",
          code: c.tools?.code,
          isLoan: false
        });
      }
    });

    const mergedItems = Array.from(toolMap.values());
    setCautelaList(mergedItems);
    setIsLoading(false);
  };

  const initBorrowSignature = () => {
    if (borrowCanvasRef.current) {
      const canvas = borrowCanvasRef.current;
      const ctx = canvas.getContext('2d');
      let drawing = false;

      const start = (e: any) => { drawing = true; draw(e); };
      const stop = () => { 
        drawing = false; 
        ctx?.beginPath(); 
        setBorrowSignature(canvas.toDataURL());
      };
      const draw = (e: any) => {
        if (!drawing || !ctx) return;
        const rect = canvas.getBoundingClientRect();
        const x = (e.clientX || e.touches[0].clientX) - rect.left;
        const y = (e.clientY || e.touches[0].clientY) - rect.top;
        ctx.lineWidth = 2;
        ctx.lineCap = 'round';
        ctx.strokeStyle = '#000';
        ctx.lineTo(x, y);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(x, y);
      };

      canvas.addEventListener('mousedown', start);
      canvas.addEventListener('mouseup', stop);
      canvas.addEventListener('mousemove', draw);
      canvas.addEventListener('touchstart', start);
      canvas.addEventListener('touchend', stop);
      canvas.addEventListener('touchmove', draw);
    }
  };

  useEffect(() => {
    if (activeScreen === 'borrow' && selectedTools.length > 0) {
      setTimeout(initBorrowSignature, 500);
    }
  }, [activeScreen, selectedTools.length]);

  const confirmBorrow = async () => {
    if (selectedTools.length === 0) return;
    setIsLoading(true);
    
    try {
      let uploadedPhotoUrl = capturedImage;
      if (capturedImage && capturedImage.startsWith('data:')) {
        const url = await uploadBase64(capturedImage, 'borrow.jpg', 'transacoes');
        if (url) uploadedPhotoUrl = url;
      }

      // 1. Create Cautelia Audit Header first
      const { data: audit, error: auditError } = await supabase
        .from('cautelia_audits')
        .insert({
          user_id: String(user?.registration || "").trim(),
          branch_id: selectedBranchId,
          signature_url: borrowSignature,
          type: borrowType,
          status: 'pending'
        })
        .select()
        .single();
      
      if (auditError || !audit) {
        console.error('Erro ao criar auditoria:', auditError);
        alert('Erro ao criar registro de auditoria.');
        setIsLoading(false);
        return;
      }

      const auditId = audit.id;
      const auditItems = [];
      const transactions = [];

      for (const t of selectedTools) {
        // Record in transactions
        transactions.push({
          tool_id: t.id,
          user_id: String(user?.registration || "").trim(),
          type: borrowType, // Use correct type (loan/caution)
          quantity: 1,
          branch: t.branch || '',
          branch_id: t.branch_id || null,
          status: 'active',
          photos: [uploadedPhotoUrl],
          obs: `Item ${borrowType === 'loan' ? 'emprestado' : 'retirado em cautela'}`
        });

        // Add to Cautelia Audit Items
        auditItems.push({
          audit_id: auditId,
          stock_tool_id: t.id,
          status: 'ok',
          quantity: 1,
          obs: `Retirada via Ferramentaria (${borrowType})`
        });

        // Also add to cautelas table so it shows up in their permanent list
        // Note: Adding 'type' specifically here as requested
        await supabase.from('cautelas').upsert({
          user_id: String(user?.registration || "").trim(),
          tool_id: t.id,
          branch_id: t.branch_id || null,
          status: 'ok',
          type: borrowType, // Use the selected type (loan/caution)
          last_check: new Date().toISOString()
        }, { onConflict: 'user_id, tool_id' });

        // Update tool stock
        const { data: currentTool } = await supabase.from('tools').select('borrowed_quantity, cautela_quantity, quantity_available, branch, branch_id').eq('id', t.id).maybeSingle();
        if (currentTool) {
          const update: any = {
            quantity_available: Math.max(0, (currentTool.quantity_available || 0) - 1)
          };
          
          if (borrowType === 'loan') {
            update.borrowed_quantity = (currentTool.borrowed_quantity || 0) + 1;
          } else {
            update.cautela_quantity = (currentTool.cautela_quantity || 0) + 1;
          }
          
          await supabase.from('tools').update(update).eq('id', t.id);
        }
      }

      if (transactions.length > 0) {
        await supabase.from('transactions').insert(transactions);
      }
      
      if (auditItems.length > 0) {
        await supabase.from('cautelia_audit_items').insert(auditItems);
      }

      confetti();
      handleAction('main');
      setCapturedImage(null);
      setSelectedTools([]);
      setBorrowSignature(null);
      
      // Refresh UI
      fetchUserProfile();
    } catch (err) {
      console.error('ERRO DETALHADO AO CONFIRMAR RETIRADA:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const updateAvatar = async (newUrl: string) => {
    if (!user) return;
    setIsLoading(true);
    try {
      const { error } = await supabase
        .from('users_access')
        .update({ avatar_url: newUrl })
        .eq('registration', user.registration);
      
      if (!error) {
        updateUser({ avatar: newUrl });
        setIsChangingAvatar(false);
        confetti();
      }
    } catch (err) {
      console.error("Erro ao atualizar avatar:", err);
    } finally {
      setIsLoading(false);
    }
  };

  // Variable no longer used, we fetch from DB

   const [isEditingPhoto, setIsEditingPhoto] = useState<string | null>(null);

   const updateToolPhoto = async (toolId: string) => {
     const canvas = document.createElement('canvas');
     if (videoRef.current) {
       canvas.width = videoRef.current.videoWidth;
       canvas.height = videoRef.current.videoHeight;
       const ctx = canvas.getContext('2d');
       ctx?.drawImage(videoRef.current, 0, 0);
       const base64 = canvas.toDataURL('image/jpeg');
       
       setIsLoading(true);
       try {
         const url = await uploadBase64(base64, `tool_${toolId}.jpg`, 'ferramentas');
         if (url) {
           await supabase.from('tools').update({ image_url: url }).eq('id', toolId);
           setStockTools(prev => prev.map(t => t.id === toolId ? { ...t, image_url: url } : t));
           confetti();
         }
       } finally {
         setIsLoading(false);
         setIsEditingPhoto(null);
         stopCamera();
       }
     }
   };

   const handleDevolver = async (item: any) => {
     setIsLoading(true);
     try {
       // 1. Get current stock
       const { data: currentTool } = await supabase.from('tools')
         .select('borrowed_quantity, cautela_quantity, quantity_available, branch, branch_id')
         .eq('id', item.tool_id)
         .maybeSingle();

       if (currentTool) {
         // 2. Prepare update
         const update: any = {
           quantity_available: (currentTool.quantity_available || 0) + 1
         };
         
         if (item.isLoan) {
           update.borrowed_quantity = Math.max(0, (currentTool.borrowed_quantity || 0) - 1);
         } else {
           update.cautela_quantity = Math.max(0, (currentTool.cautela_quantity || 0) - 1);
         }
         
         // 3. Update stock
         await supabase.from('tools').update(update).eq('id', item.tool_id);
       }

       // 4. Record return transaction
       await supabase.from('transactions').insert([{
         tool_id: item.tool_id,
         user_id: user?.registration || '',
         type: 'return',
         quantity: 1,
         branch: user?.branch_id || currentTool?.branch || '',
         branch_id: user?.branch_id || currentTool?.branch_id || null,
         status: 'completed',
         obs: `Ferramenta devolvida por ${user?.name || user?.registration}`
       }]);

       // 5. Remove record
       if (item.type === 'standard') {
         await supabase.from('cautelia_reports')
           .delete()
           .eq('user_id', String(user?.registration || "").trim())
           .eq('tool_id', item.tool_id);
       } else {
         await supabase.from('cautelas')
           .delete()
           .eq('user_id', String(user?.registration || "").trim())
           .eq('tool_id', item.tool_id);
       }
       
       fetchUserProfile();
       confetti();
       alert("Ferramenta devolvida com sucesso!");
     } catch (err) {
       console.error("Erro ao devolver:", err);
       alert("Erro ao devolver ferramenta.");
     } finally {
       setIsLoading(false);
     }
   };

  return (
    <div className="max-w-xl mx-auto h-[calc(100vh-8rem)] flex flex-col font-sans relative">
      <AnimatePresence mode="wait">
        {/* MAIN GAME MENU */}
        {activeScreen === 'main' && (
          <motion.div 
            key="main"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, x: -100 }}
            className="flex-1 flex flex-col gap-6"
          >
            {/* Pending Audit Card */}
            {pendingAudit && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-amber-50 border-2 border-amber-200 p-6 rounded-[2rem] shadow-lg flex flex-col gap-4"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-amber-500 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-amber-200">
                    <AlertTriangle size={24} />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-sm font-black italic uppercase tracking-tight text-amber-900 leading-none">Ação Pendente</h3>
                    <p className="text-[10px] text-amber-600 font-bold uppercase mt-1 tracking-widest">Você possui 1 cautelia aguardando assinatura</p>
                  </div>
                </div>
                
                <div className="flex gap-3 mt-2">
                  <button 
                    onClick={() => setIsSigningPending(true)}
                    className="flex-1 bg-amber-500 hover:bg-amber-600 text-white font-black italic py-3 rounded-2xl shadow-lg shadow-amber-200 text-xs uppercase tracking-widest transition-all active:scale-95 flex items-center justify-center gap-2"
                  >
                    <FileCheck size={16} /> Coletar Assinatura Agora
                  </button>
                </div>
              </motion.div>
            )}

            {/* Header / Profile Card */}
            <div className="bg-gradient-to-br from-indigo-600 to-purple-600 p-6 rounded-[2rem] shadow-xl text-white relative overflow-hidden">
               <div className="relative z-10">
                  <div className="flex items-center gap-4 mb-4">
                    <div 
                      className="relative w-16 h-16 rounded-2xl overflow-hidden border-2 border-white/20 shadow-lg bg-indigo-950 flex items-center justify-center cursor-pointer group"
                      onClick={() => setIsChangingAvatar(true)}
                    >
                        <Image 
                          src={user?.avatar || `https://api.dicebear.com/9.x/avataaars/svg?seed=${encodeURIComponent(user?.name || 'User')}&backgroundType=gradientLinear&backgroundColor=b6e3f4,c0aede,d1d4f9`}
                          alt="Avatar" 
                          fill 
                          sizes="64px"
                          unoptimized
                          priority
                          className="object-cover group-hover:scale-110 transition-transform"
                          referrerPolicy="no-referrer"
                          key={user?.avatar}
                          onError={(e) => {
                            const target = e.target as HTMLImageElement;
                            target.src = `https://api.dicebear.com/9.x/avataaars/svg?seed=${encodeURIComponent(user?.name || 'User')}&backgroundType=gradientLinear&backgroundColor=b6e3f4,c0aede,d1d4f9`;
                          }}
                        />
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                          <User size={20} className="text-white" />
                        </div>
                    </div>
                    <div>
                      <h2 className="text-xl font-black italic tracking-tighter">Bem vindo ao FerramentarIA,</h2>
                      <p className="text-2xl font-black uppercase">{user?.name?.split(' ')?.[0] || 'TÉCNICO'}!</p>
                    </div>
                 </div>

                 <div className="flex bg-black/20 backdrop-blur p-4 rounded-2xl border border-white/10 mt-4 items-center justify-between">
                    <div className="flex items-center gap-3">
                       <div className="p-2 bg-amber-400 rounded-lg text-amber-900 shadow-lg shadow-amber-400/20">
                         <Trophy size={20} />
                       </div>
                       <div>
                         <p className="text-sm font-black italic">Ferramentaria</p>
                       </div>
                     </div>
                 </div>
               </div>
               {/* Background elements */}
               <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-3xl -mr-10 -mt-10" />
               <div className="absolute bottom-0 left-0 w-24 h-24 bg-blue-500/20 rounded-full blur-2xl -ml-5 -mb-5" />
            </div>

            {/* Menu Grid */}
            <div className="grid grid-cols-2 gap-4 flex-1">
               <MenuButton 
                  label="Empréstimo" 
                  icon={Scan} 
                  color="bg-emerald-500 shadow-emerald-200" 
                  desc="Escaneie para tirar do estoque"
                  onClick={() => handleAction('borrow')}
               />
               <MenuButton 
                  label="Cautelas" 
                  icon={ClipboardList} 
                  color="bg-amber-500 shadow-amber-200" 
                  desc="Checklist diário pessoal"
                  onClick={() => handleAction('cautela')}
               />
               <MenuButton 
                  label="Estoque" 
                  icon={Package} 
                  color="bg-blue-500 shadow-blue-200" 
                  desc="Ver o que tem e onde está"
                  onClick={() => handleAction('stock')}
               />
               <MenuButton 
                  label="Meu Perfil" 
                  icon={User} 
                  color="bg-slate-800 shadow-slate-300" 
                  desc="Suas ferramentas e histórico"
                  onClick={() => handleAction('profile')}
               />
            </div>


          </motion.div>
        )}

         {/* BORROW SCREEN */}
         {activeScreen === 'borrow' && (
           <motion.div 
             key="borrow"
             initial={{ opacity: 0, x: 100 }}
             animate={{ opacity: 1, x: 0 }}
             exit={{ opacity: 0, x: 100 }}
             className="flex-1 flex flex-col bg-slate-50 rounded-[2rem] shadow-xl overflow-hidden relative"
           >
              {/* FIXED HEADER */}
              <div className="p-6 bg-emerald-500 text-white flex items-center justify-between shadow-lg z-20 shrink-0">
                 <button onClick={() => setActiveScreen('main')} className="p-2 hover:bg-white/20 rounded-xl transition-all">
                   <X size={20} />
                 </button>
                 <div className="text-center">
                   <h2 className="font-black italic uppercase tracking-tight leading-none text-sm">RETIRADA</h2>
                   <p className="text-[8px] font-black uppercase opacity-70 tracking-widest mt-1">{selectedTools.length} ITENS SELECIONADOS</p>
                 </div>
                 <button 
                   onClick={() => { setCapturedImage(null); initCamera(); }} 
                   className="p-2 bg-white/20 hover:bg-white/40 rounded-xl transition-all"
                 >
                   <Camera size={20} />
                 </button>
              </div>

              {/* SCROLLABLE CONTENT */}
             <div className="flex-1 overflow-y-auto px-6 py-4 custom-scrollbar pb-64">
                {!selectedBranchId && (
                  <div className="mb-6 p-4 bg-amber-50 border-2 border-amber-200 rounded-3xl text-center">
                    <p className="text-[10px] font-black text-amber-600 uppercase tracking-widest mb-3">Selecione a Filial para Iniciar</p>
                    <select 
                      value={selectedBranchId}
                      onChange={(e) => setSelectedBranchId(e.target.value)}
                      className="w-full px-4 py-3 bg-white border-none rounded-xl text-[10px] font-black uppercase shadow-sm"
                    >
                      <option value="">Escolha uma filial...</option>
                      {branches.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                    </select>
                  </div>
                )}

                {isCameraOpen ? (
                   <div className="flex flex-col items-center justify-center py-4">
                      <div className="relative w-full aspect-square max-w-xs bg-black rounded-[3rem] overflow-hidden shadow-2xl border-4 border-white/20">
                         <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
                         <div className="absolute inset-0 border-2 border-emerald-500/50 rounded-[3rem] pointer-events-none flex items-center justify-center">
                            <div className="w-48 h-48 border-2 border-white/40 border-dashed rounded-3xl" />
                         </div>
                         <button 
                            onClick={takePhoto}
                            className="absolute bottom-6 left-1/2 -translate-x-1/2 w-16 h-16 bg-white border-4 border-emerald-500 rounded-full flex items-center justify-center shadow-lg active:scale-90 transition-all"
                         >
                           <Camera size={32} className="text-emerald-500" />
                         </button>
                      </div>
                      <button onClick={stopCamera} className="mt-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Fechar Câmera</button>
                   </div>
                ) : (
                  <div className="space-y-4">
                    {/* Search and Selection Area */}
                    <div className="space-y-4">
                       <div className="relative group">
                          <Search size={18} className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-emerald-500 transition-colors" />
                          <input 
                            type="text"
                            placeholder="ADICIONAR MAIS (NOME OU CÓD) ..."
                            value={manualSearchTerm}
                            onChange={(e) => {
                              setManualSearchTerm(e.target.value);
                              searchManualTools(e.target.value, selectedBranchId);
                            }}
                            className="w-full pl-14 pr-5 py-4 bg-white border-none focus:ring-2 focus:ring-emerald-500/20 rounded-2xl text-[10px] font-black uppercase tracking-widest text-slate-700 shadow-sm"
                          />
                       </div>

                       {isAnalyzing && (
                         <div className="flex items-center gap-3 p-4 bg-emerald-50 rounded-2xl border border-emerald-100 animate-pulse">
                            <div className="w-4 h-4 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin" />
                            <p className="text-[9px] font-black text-emerald-600 uppercase">AXEL Analisando foto...</p>
                         </div>
                       )}

                       {/* Search Results / Suggestion List */}
                       {manualSearchTerm && detectedTools.length > 0 && (
                         <div className="grid gap-2 p-2 bg-white rounded-3xl border border-slate-100 shadow-xl overflow-hidden">
                            {detectedTools.filter(t => !selectedTools.find(st => st.id === t.id)).map(t => (
                               <button 
                                 key={t.id} 
                                 onClick={() => {
                                   setSelectedTools(prev => [...prev, t]);
                                   setManualSearchTerm('');
                                   setDetectedTools([]);
                                 }}
                                 className="flex items-center gap-3 p-3 hover:bg-slate-50 transition-colors text-left border-b border-slate-50 last:border-0"
                               >
                                  <div className="w-10 h-10 bg-slate-100 rounded-lg shrink-0 flex items-center justify-center">
                                     {t.image_url ? <Image src={t.image_url} alt="T" width={40} height={40} className="object-cover rounded-lg" /> : <Package size={16} className="text-slate-300" />}
                                  </div>
                                  <div className="flex-1">
                                    <p className="text-[10px] font-black uppercase text-slate-700 leading-none">{t.name}</p>
                                    <p className="text-[8px] font-bold text-slate-400 uppercase mt-0.5">#{t.code}</p>
                                  </div>
                                  <ChevronRight size={16} className="text-slate-300" />
                               </button>
                            ))}
                         </div>
                       )}
                    </div>

                    {/* Selected List Section */}
                    <div>
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">ITENS PARA RETIRAR ({selectedTools.length})</h3>
                        {selectedTools.length > 0 && (
                          <button onClick={() => setSelectedTools([])} className="text-[9px] font-black text-rose-500 uppercase tracking-tighter">Limpar Tudo</button>
                        )}
                      </div>
                      
                      {selectedTools.length === 0 ? (
                        <div className="py-12 text-center bg-white rounded-[2rem] border-2 border-dashed border-slate-200">
                           <ClipboardList size={40} className="text-slate-200 mx-auto mb-3" />
                           <p className="text-[10px] font-black text-slate-300 uppercase tracking-widest px-10 leading-relaxed">Sua lista está vazia.<br/>Escaneie ou procure sua ferramenta.</p>
                        </div>
                      ) : (
                        <div className="grid gap-3">
                           {selectedTools.map((t, idx) => (
                             <motion.div 
                               key={t.id}
                               initial={{ opacity: 0, y: 10 }}
                               animate={{ opacity: 1, y: 0 }}
                               className="flex items-center gap-4 p-4 bg-white rounded-3xl shadow-sm border border-slate-100 group"
                             >
                                <div className="w-12 h-12 bg-slate-50 rounded-xl relative overflow-hidden flex items-center justify-center border border-slate-100">
                                   {t.image_url ? <Image src={t.image_url} alt="T" fill sizes="48px" className="object-cover" /> : <Package size={20} className="text-slate-300" />}
                                </div>
                                <div className="flex-1">
                                  <p className="text-[11px] font-black uppercase italic text-slate-800 leading-none">{t.name}</p>
                                  <div className="flex items-center gap-2 mt-1">
                                     <p className="text-[9px] font-black text-indigo-500 uppercase tracking-tighter bg-indigo-50 w-fit px-2 py-0.5 rounded">#{t.code}</p>
                                     <p className="text-[9px] font-black text-slate-400 uppercase tracking-tighter bg-slate-50 w-fit px-2 py-0.5 rounded">Disp: {t.quantity_available}</p>
                                  </div>
                                </div>
                                <button 
                                  onClick={() => setSelectedTools(prev => prev.filter(st => st.id !== t.id))}
                                  className="p-2 hover:bg-rose-50 hover:text-rose-500 text-slate-300 rounded-xl transition-all"
                                >
                                  <X size={18} />
                                </button>
                             </motion.div>
                           ))}
                        </div>
                      )}
                    </div>
                  </div>
                )}
             </div>

             {/* STICKY ACTION PANEL */}
             <div className="absolute bottom-0 left-0 right-0 bg-white border-t border-slate-200 p-6 shadow-[0_-10px_40px_rgba(0,0,0,0.1)] z-30 flex flex-col gap-4">
                {selectedTools.length > 0 && (
                   <div className="animate-in slide-in-from-bottom-5 duration-300">
                      {/* TYPE SWITCH & SIGNATURE COMPACT */}
                      <div className="flex gap-4 mb-4">
                         <div className="flex-1 bg-slate-50 p-1 rounded-2xl flex">
                            <button 
                              onClick={() => setBorrowType('loan')}
                              className={`flex-1 py-2 text-[9px] font-black uppercase tracking-widest rounded-xl transition-all ${borrowType === 'loan' ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-200' : 'text-slate-400'}`}
                            >
                              Empréstimo
                            </button>
                            <button 
                              onClick={() => setBorrowType('caution')}
                              className={`flex-1 py-2 text-[9px] font-black uppercase tracking-widest rounded-xl transition-all ${borrowType === 'caution' ? 'bg-amber-500 text-white shadow-lg shadow-amber-200' : 'text-slate-400'}`}
                            >
                              Cautela
                            </button>
                         </div>
                         <div className="w-40 h-12 bg-white rounded-2xl border border-slate-200 relative overflow-hidden flex items-center justify-center group">
                            <canvas ref={borrowCanvasRef} width={160} height={48} className="w-full h-full cursor-crosshair" />
                            {!borrowSignature && <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-40 text-[7px] font-black uppercase text-slate-400">Assine aqui</div>}
                            <button 
                              onClick={() => {
                                const ctx = borrowCanvasRef.current?.getContext('2d');
                                ctx?.clearRect(0,0, 160, 48);
                                setBorrowSignature(null);
                              }}
                              className="absolute right-1 bottom-1 text-[6px] font-black text-rose-400 opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                              LIMPAR
                            </button>
                         </div>
                      </div>

                      <button 
                        onClick={confirmBorrow}
                        disabled={isLoading}
                        className="w-full bg-emerald-500 text-white font-black italic py-5 rounded-[2rem] shadow-xl shadow-emerald-200 flex items-center justify-center gap-3 text-lg disabled:opacity-50 disabled:grayscale transition-all active:scale-95"
                      >
                        {isLoading ? <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <>FINALIZAR RETIRADA <ArrowRight size={20} /></>}
                      </button>
                   </div>
                )}
                
                {selectedTools.length === 0 && (
                   <button 
                     onClick={initCamera} 
                     disabled={!selectedBranchId}
                     className="w-full bg-indigo-600 text-white font-black italic py-5 rounded-[2rem] shadow-xl shadow-indigo-100 flex items-center justify-center gap-3 text-lg active:scale-95 transition-all"
                   >
                     <Camera size={20} /> LIGAR CÂMERA SCANNER
                   </button>
                )}
             </div>
          </motion.div>
        )}

        {/* STOCK SCREEN */}
        {activeScreen === 'stock' && (
          <motion.div 
            key="stock"
            initial={{ opacity: 0, x: 100 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 100 }}
            className="flex-1 flex flex-col bg-white rounded-[2rem] shadow-xl overflow-hidden"
          >
             <div className="p-6 bg-blue-600 text-white flex items-center justify-between">
                <button onClick={() => setActiveScreen('main')} className="p-2 hover:bg-white/20 rounded-xl transition-all">
                  <X size={20} />
                </button>
                <h2 className="font-black italic uppercase tracking-tight">ESTOQUE DO HUB</h2>
                <div className="w-10 h-10" />
             </div>
             
             <div className="p-6 space-y-4 overflow-y-auto flex-1 custom-scrollbar">
                {isLoading ? (
                   <div className="py-20 text-center">
                     <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
                     <p className="text-[10px] font-black text-slate-400 uppercase">Consultando estoque...</p>
                   </div>
                ) : stockTools.map(tool => (
                  <div key={tool.id} className="p-4 bg-slate-50 rounded-2xl border border-slate-100 flex flex-col gap-4">
                     <div className="flex items-center gap-4">
                        <div className="w-16 h-16 bg-white rounded-xl flex items-center justify-center border border-slate-200 relative overflow-hidden">
                           {tool.image_url ? <Image src={tool.image_url} alt={tool.name} fill sizes="64px" className="object-cover" /> : <Package size={24} className="text-slate-300" />}
                        </div>
                        <div className="flex-1">
                           <p className="text-xs font-black uppercase text-slate-800">{tool.name}</p>
                           <p className="text-[9px] font-mono font-bold text-slate-400">COD: {tool.code}</p>
                           <div className="flex gap-2 mt-2">
                              <span className="text-[8px] bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-md font-black uppercase">Disp: {tool.quantity_available}</span>
                              <span className="text-[8px] bg-blue-100 text-blue-700 px-2 py-0.5 rounded-md font-black uppercase">Loan: {tool.borrowed_quantity}</span>
                           </div>
                        </div>
                        <button 
                          onClick={() => {
                            setIsEditingPhoto(tool.id);
                            initCamera();
                          }}
                          className="p-2 bg-indigo-50 text-indigo-600 rounded-xl shadow-sm hover:scale-110 active:scale-95 transition-all text-[8px] font-black uppercase tracking-tighter"
                        >
                          {tool.image_url ? 'Trocar Foto' : 'Add Foto'}
                        </button>
                     </div>
                     
                     {isEditingPhoto === tool.id && (
                        <div className="space-y-3 p-3 bg-indigo-900 rounded-xl overflow-hidden mt-2">
                           <div className="relative aspect-video bg-black rounded-lg overflow-hidden">
                             <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
                           </div>
                           <div className="flex gap-2">
                              <button 
                                onClick={() => {
                                  stopCamera();
                                  setIsEditingPhoto(null);
                                }} 
                                className="flex-1 py-2 bg-slate-700 text-white rounded-lg text-[10px] font-black uppercase"
                              >
                                Cancelar
                              </button>
                              <button 
                                onClick={() => updateToolPhoto(tool.id)} 
                                className="flex-1 py-2 bg-indigo-500 text-white rounded-lg text-[10px] font-black uppercase"
                              >
                                {isLoading ? 'Salvando...' : 'Capturar Foto'}
                              </button>
                           </div>
                        </div>
                     )}
                  </div>
                ))}
             </div>
          </motion.div>
        )}

        {/* PROFILE SCREEN */}
        {activeScreen === 'profile' && (
          <motion.div 
            key="profile"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="flex-1 flex flex-col bg-slate-900 text-white rounded-[2rem] shadow-xl overflow-hidden"
          >
             <div className="p-8 text-center bg-gradient-to-b from-slate-800 to-slate-900">
                <div className="relative w-28 h-28 mx-auto mb-6">
                   <div className="absolute inset-0 bg-indigo-500 rounded-3xl rotate-6 scale-110 opacity-20" />
                   <div className="relative w-full h-full rounded-3xl overflow-hidden border-4 border-slate-700 bg-slate-800 shadow-2xl flex items-center justify-center">
                      <Image 
                        src={user?.avatar || `https://api.dicebear.com/9.x/avataaars/svg?seed=${encodeURIComponent(user?.name || 'User')}&backgroundType=gradientLinear&backgroundColor=b6e3f4,c0aede,d1d4f9`}
                        alt="Avatar" 
                        fill 
                        sizes="112px"
                        unoptimized
                        className="object-cover"
                        referrerPolicy="no-referrer"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.src = `https://api.dicebear.com/9.x/avataaars/svg?seed=${encodeURIComponent(user?.name || 'User')}&backgroundType=gradientLinear&backgroundColor=b6e3f4,c0aede,d1d4f9`;
                        }}
                      />
                   </div>
                   <div className="absolute -bottom-2 -right-2 p-2 bg-amber-400 text-slate-900 rounded-2xl shadow-xl">
                      <Trophy size={20} />
                   </div>
                </div>
                <h2 className="text-3xl font-black italic tracking-tighter">{user?.name}</h2>
             </div>

             <div className="flex-1 bg-white p-6 rounded-t-[3rem] text-slate-900 space-y-6 overflow-y-auto custom-scrollbar">
                <div className="flex items-center justify-between">
                   <h3 className="font-black italic text-xl uppercase tracking-tighter">MEUS EQUIPAMENTOS</h3>
                   <div className="flex gap-2">
                     <button 
                       onClick={() => setIsChangingAvatar(true)}
                       className="p-2 bg-indigo-50 text-indigo-600 rounded-xl flex items-center gap-2 text-[10px] font-black uppercase tracking-widest border border-indigo-100"
                     >
                       <User size={14} /> Trocar Avatar
                     </button>
                     <button onClick={() => setActiveScreen('main')} className="p-2 bg-slate-100 rounded-xl"><X size={20} /></button>
                   </div>
                </div>
                
                <div className="space-y-4">
                   {userTools.length === 0 ? (
                      <div className="p-10 text-center border-4 border-dashed border-slate-100 rounded-[2rem]">
                         <Package size={40} className="mx-auto text-slate-200 mb-4" />
                         <p className="text-xs font-black text-slate-300 uppercase">Nada emprestado com você</p>
                      </div>
                   ) : userTools.map(item => (
                      <div key={item.id} className="p-5 bg-slate-50 rounded-3xl border border-slate-200 flex items-center gap-4">
                         <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center border border-slate-200 overflow-hidden relative">
                           {item.image ? (
                             <Image src={item.image} alt="Tool" fill sizes="56px" className="object-cover" />
                           ) : (
                             item.type === 'standard' ? <Zap size={24} className="text-amber-500" /> : <Package size={24} className="text-slate-300" />
                           )}
                           <div className={`absolute top-0 right-0 px-1 py-0.5 text-[5px] font-black uppercase text-white ${item.isLoan ? 'bg-purple-600' : (item.type === 'standard' ? 'bg-indigo-500' : 'bg-amber-500')}`}>
                             {item.isLoan ? 'EMPRÉSTIMO' : (item.type === 'standard' ? 'PADRÃO' : 'CAUTELA')}
                           </div>
                         </div>
                         <div className="flex-1">
                            <p className="text-xs font-black uppercase italic leading-none">{item.name}</p>
                            <p className="text-[10px] text-slate-400 font-bold mt-1">
                              {item.type === 'standard' ? 'VINCULADO EM: ' : 'RETIRADO EM: '} 
                              {new Date(item.date).toLocaleDateString()}
                            </p>
                         </div>
                         {item.type === 'big' && (
                           <button onClick={() => handleDevolver(item)} className="text-rose-500 font-black text-[10px] uppercase tracking-widest bg-white px-4 py-2 rounded-xl shadow-sm border border-slate-100 whitespace-nowrap">Devolver</button>
                         )}
                      </div>
                   ))}
                </div>
             </div>
          </motion.div>
        )}

        {/* CAUTELA SCREEN */}
        {activeScreen === 'cautela' && (
          <CautelaCheckScreen user={user} onBack={() => setActiveScreen('main')} />
        )}
      </AnimatePresence>

      {/* PENDING SIGNATURE MODAL */}
      <AnimatePresence>
        {isSigningPending && pendingAudit && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-900/90 backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="bg-white w-full max-w-md rounded-[2.5rem] overflow-hidden shadow-2xl flex flex-col h-[85vh]"
            >
              <div className="p-6 bg-amber-500 text-white flex justify-between items-center shrink-0">
                <div>
                   <h3 className="font-black italic text-lg uppercase tracking-tight leading-none">Assinar Cautelia</h3>
                   <p className="text-[9px] font-black uppercase opacity-70 tracking-widest mt-1">Audit ID: {pendingAudit.id}</p>
                </div>
                <button onClick={() => setIsSigningPending(false)} className="p-2 bg-white/20 rounded-xl"><X size={20} /></button>
              </div>
              
              <div className="p-6 flex-1 overflow-y-auto space-y-6 custom-scrollbar">
                <div className="space-y-3">
                   <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100 pb-2">ITENS NA CAUTELIA</p>
                   {(pendingAudit.cautelia_audit_items || []).map((item: any, idx: number) => (
                      <div key={idx} className="flex items-center gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-100">
                         <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center border border-slate-100 shrink-0">
                            {item.tools?.image_url ? (
                              <Image src={item.tools.image_url} alt="T" width={40} height={40} className="object-cover rounded-xl" />
                            ) : (
                              <Package size={16} className="text-slate-300" />
                            )}
                         </div>
                         <div className="flex-1">
                            <p className="text-[10px] font-black uppercase italic text-slate-700 leading-tight">
                              {item.cautelia_standard_tools?.name || item.tools?.name || 'Ferramenta Desconhecida'}
                            </p>
                            <p className="text-[8px] font-black text-slate-400 mt-1 uppercase">
                              {item.status ? `Status: ${item.status}` : 'OK'}
                            </p>
                         </div>
                      </div>
                   ))}
                </div>

                <div className="pt-4 space-y-4">
                   <div className="text-center">
                      <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none">ASSINE DIGITALMENTE PARA CONFIRMAR</h3>
                      <p className="text-[8px] text-slate-300 mt-2 font-bold uppercase">Declaro o recebimento ou revisão dos itens acima.</p>
                   </div>
                   <div className="bg-slate-50 rounded-3xl border-2 border-slate-200 h-40 overflow-hidden relative">
                      <canvas 
                        ref={(ref) => {
                          if (ref) {
                            const ctx = ref.getContext('2d');
                            let drawing = false;
                            const start = (e: any) => { drawing = true; draw(e); };
                            const stop = () => { drawing = false; ctx?.beginPath(); };
                            const draw = (e: any) => {
                              if (!drawing || !ctx) return;
                              const rect = ref.getBoundingClientRect();
                              const x = (e.clientX || (e.touches && e.touches[0].clientX)) - rect.left;
                              const y = (e.clientY || (e.touches && e.touches[0].clientY)) - rect.top;
                              ctx.lineWidth = 2;
                              ctx.lineCap = 'round';
                              ctx.strokeStyle = '#000';
                              ctx.lineTo(x, y);
                              ctx.stroke();
                              ctx.beginPath();
                              ctx.moveTo(x, y);
                            };
                            ref.addEventListener('mousedown', start);
                            ref.addEventListener('mouseup', stop);
                            ref.addEventListener('mousemove', draw);
                            ref.addEventListener('touchstart', start);
                            ref.addEventListener('touchend', stop);
                            ref.addEventListener('touchmove', draw);
                          }
                        }}
                        width={400} 
                        height={160} 
                        className="w-full h-full cursor-crosshair" 
                      />
                      <button 
                        onClick={(e) => {
                          const canvas = (e.currentTarget.previousSibling as HTMLCanvasElement);
                          const ctx = canvas.getContext('2d');
                          ctx?.clearRect(0, 0, canvas.width, canvas.height);
                        }} 
                        className="absolute bottom-2 right-2 text-[8px] font-black uppercase text-slate-300 hover:text-rose-500"
                      >
                        Limpar
                      </button>
                   </div>

                   <button 
                    onClick={async (e) => {
                      const canvas = (e.currentTarget.previousSibling?.previousSibling as HTMLCanvasElement);
                      const sig = canvas.toDataURL();
                      setIsLoading(true);
                      try {
                        // 1. Update the audit status and signature
                        const { error: updateErr } = await supabase
                          .from('cautelia_audits')
                          .update({ 
                            status: 'signed', 
                            signature_url: sig,
                            check_date: new Date().toISOString()
                          })
                          .eq('id', pendingAudit.id);
                        
                        if (updateErr) throw updateErr;

                        // 2. Sync to cautelas/reports
                        for (const item of (pendingAudit.cautelia_audit_items || [])) {
                          if (item.tool_id) {
                            await supabase.from('cautelia_reports').upsert({
                              user_id: pendingAudit.user_id,
                              tool_id: item.tool_id,
                              status: item.status || 'ok',
                              last_check: new Date().toISOString()
                            }, { onConflict: 'user_id, tool_id' });
                          } else if (item.stock_tool_id) {
                            await supabase.from('cautelas').upsert({
                              user_id: pendingAudit.user_id,
                              tool_id: item.stock_tool_id,
                              status: item.status || 'ok',
                              last_check: new Date().toISOString()
                            }, { onConflict: 'user_id, tool_id' });
                          }
                        }

                        confetti();
                        setIsSigningPending(false);
                        setPendingAudit(null);
                        handleAction('main');
                        fetchPendingAudit();
                        fetchUserProfile();
                      } catch (err) {
                        console.error(err);
                        alert("Erro ao finalizar assinatura.");
                      } finally {
                        setIsLoading(false);
                      }
                    }}
                    disabled={isLoading}
                    className="w-full bg-slate-900 text-white font-black italic py-5 rounded-[2rem] shadow-2xl flex items-center justify-center gap-3 active:scale-95 transition-all text-lg uppercase"
                   >
                     {isLoading ? 'ENVIANDO...' : 'CONFIRMAR ASSINATURA'}
                   </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* AVATAR CHANGE MODAL */}
      <AnimatePresence>
        {isChangingAvatar && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-md"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="bg-white w-full max-w-md rounded-[2.5rem] overflow-hidden shadow-2xl flex flex-col h-[80vh]"
            >
              <div className="p-6 bg-indigo-600 text-white flex justify-between items-center shrink-0">
                <h3 className="font-black italic text-lg uppercase tracking-tight">CATÁLOGO DE AVATARES</h3>
                <button onClick={() => setIsChangingAvatar(false)}><X size={24} /></button>
              </div>
              
              <div className="p-8 flex-1 overflow-y-auto space-y-8 custom-scrollbar">
                <div className="flex justify-center">
                   <div className="relative w-32 h-32 rounded-full border-4 border-indigo-100 shadow-xl overflow-hidden bg-indigo-50 flex items-center justify-center">
                      <Image 
                        src={avatarSeed || user?.avatar || `https://api.dicebear.com/9.x/avataaars/svg?seed=${encodeURIComponent(user?.name || 'User')}`} 
                        alt="Preview" 
                        fill 
                        sizes="128px"
                        unoptimized
                        key={avatarSeed}
                        className="object-cover"
                        referrerPolicy="no-referrer"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.src = `https://api.dicebear.com/9.x/avataaars/svg?seed=${encodeURIComponent(user?.name || 'User')}&backgroundType=gradientLinear&backgroundColor=b6e3f4,c0aede,d1d4f9`;
                        }}
                      />
                   </div>
                </div>

                <div className="space-y-6 flex-1 pr-1">
                   {/* Grouped by Category */}
                   {Array.from(new Set(avatarsList.map(a => a.category))).map(category => (
                     <div key={category} className="space-y-3">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">{category}</p>
                        <div className="grid grid-cols-4 gap-3">
                           {avatarsList.filter(a => a.category === category).map(avatar => (
                             <button 
                               key={avatar.id}
                               onClick={() => setAvatarSeed(avatar.url)}
                               className={`relative aspect-square rounded-2xl overflow-hidden border-2 transition-all hover:scale-105 active:scale-95 ${avatarSeed === avatar.url ? 'border-indigo-500 shadow-lg shadow-indigo-100' : 'border-slate-100 opacity-80'}`}
                             >
                                <Image 
                                  src={avatar.url}
                                  alt="Opção"
                                  fill
                                  unoptimized
                                  sizes="80px"
                                  className="object-cover"
                                />
                                {avatarSeed === avatar.url && (
                                  <div className="absolute inset-0 bg-indigo-500/10 flex items-center justify-center">
                                     <CheckCircle2 className="text-indigo-600" size={24} />
                                  </div>
                                )}
                             </button>
                           ))}
                        </div>
                     </div>
                   ))}
                </div>
              </div>

              <div className="p-6 bg-slate-50 border-t border-slate-100 shrink-0">
                <button 
                  onClick={() => updateAvatar(avatarSeed)}
                  disabled={!avatarSeed || isLoading}
                  className="w-full py-4 bg-indigo-600 text-white font-black italic rounded-3xl shadow-xl shadow-indigo-100 flex items-center justify-center gap-3 hover:bg-indigo-700 active:scale-95 transition-all disabled:opacity-50"
                >
                  {isLoading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <>DEFINIR NOVO AVATAR <CheckCircle2 size={18} /></>}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function CautelaCheckScreen({ user, onBack }: any) {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [signatures, setSignatures] = useState<string | null>(null);
  const [showChangeWarning, setShowChangeWarning] = useState(false);
  const [hasNotifiedWarning, setHasNotifiedWarning] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const fetchItems = React.useCallback(async () => {
    let reg = String(user?.registration || "").trim();
    if (!reg) {
      setLoading(false);
      return;
    }

    try {
      const [reportsResp, cautelasResp, transResp] = await Promise.all([
        supabase
          .from('cautelia_reports')
          .select('*, cautelia_standard_tools(*)')
          .eq('user_id', reg),
        supabase
          .from('cautelas')
          .select('*, tools(id, name, code, image_url)')
          .eq('user_id', reg),
        supabase
          .from('transactions')
          .select('*, tools(id, name, code, image_url)')
          .eq('user_id', reg)
          .in('status', ['active', 'confirmed'])
      ]);

      const toolMap = new Map();

      // 1. Kits/Standard tools
      reportsResp.data?.forEach(r => {
        if (r.cautelia_standard_tools) {
          toolMap.set(`std-${r.tool_id}`, {
            id: `std-${r.tool_id}`,
            db_id: r.id, 
            tool_id: r.tool_id,
            name: r.cautelia_standard_tools.name,
            code: `STD-${r.tool_id.substring(0, 4).toUpperCase()}`,
            status: r.status || 'ok',
            type: 'standard',
            obs: r.obs || ''
          });
        }
      });

      // 2. Big/Stock tools (from Cautelas)
      cautelasResp.data?.forEach(c => {
        const tipo = String(c.type || '').toLowerCase().trim();
        const isLoan = tipo === 'loan' || tipo === 'emprestimo' || tipo === 'empréstimo' || tipo === 'borrow';
        
        // Filtro Inverso: Remove apenas o que for comprovadamente empréstimo
        if (c.tools && !isLoan) {
          toolMap.set(`big-${c.tool_id}`, {
            id: `big-${c.tool_id}`,
            db_id: c.id,
            tool_id: c.tool_id,
            name: c.tools.name,
            code: c.tools.code || 'S/N',
            status: c.status || 'ok',
            type: 'big',
            obs: c.obs || ''
          });
        }
      });

      // 3. Fallback from fallback (Active transactions)
      transResp.data?.forEach(t => {
        const tipo = String(t.type || '').toLowerCase().trim();
        const isLoan = tipo === 'loan' || tipo === 'emprestimo' || tipo === 'empréstimo' || tipo === 'borrow';

        // Filtro Inverso
        if (t.tools && !isLoan && !toolMap.has(`big-${t.tool_id}`)) {
          // If it's active in transactions and not in cautelas yet
          toolMap.set(`big-${t.tool_id}`, {
            id: `big-${t.tool_id}`,
            db_id: t.id,
            tool_id: t.tool_id,
            name: t.tools.name,
            code: t.tools.code || 'S/N',
            status: 'ok',
            type: 'big',
            obs: ''
          });
        }
      });

      setItems(Array.from(toolMap.values()));
    } catch (err) {
      console.error("Error fetching checklist items:", err);
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    const init = async () => {
      if (user?.registration) {
         await fetchItems();
      }
    };
    init();
  }, [fetchItems, user?.registration]);

  const updateItemStatus = (id: string, status: any) => {
    const item = items.find(i => i.id === id);
    if (!item || item.status === status) return;

    setItems(prev => prev.map(i => i.id === id ? { ...i, status } : i));
    
    if (!hasNotifiedWarning) {
      setShowChangeWarning(true);
      setHasNotifiedWarning(true);
    }
  };

  const handleSignature = React.useCallback(() => {
    if (canvasRef.current) {
      setSignatures(canvasRef.current.toDataURL());
    }
  }, []);

  const clearSignature = () => {
    if (canvasRef.current) {
      const ctx = canvasRef.current.getContext('2d');
      ctx?.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
      setSignatures(null);
    }
  };

  const initSignaturePad = React.useCallback(() => {
    if (canvasRef.current) {
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      let drawing = false;

      const start = (e: any) => { drawing = true; draw(e); };
      const stop = () => { drawing = false; ctx?.beginPath(); handleSignature(); };
      const draw = (e: any) => {
        if (!drawing || !ctx) return;
        const rect = canvas.getBoundingClientRect();
        const x = (e.clientX || e.touches[0].clientX) - rect.left;
        const y = (e.clientY || e.touches[0].clientY) - rect.top;
        ctx.lineWidth = 2;
        ctx.lineCap = 'round';
        ctx.strokeStyle = '#000';
        ctx.lineTo(x, y);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(x, y);
      };

      canvas.addEventListener('mousedown', start);
      canvas.addEventListener('mouseup', stop);
      canvas.addEventListener('mousemove', draw);
      canvas.addEventListener('touchstart', start);
      canvas.addEventListener('touchend', stop);
      canvas.addEventListener('touchmove', draw);
    }
  }, [handleSignature]);

  useEffect(() => { if (!loading) setTimeout(initSignaturePad, 500); }, [loading, initSignaturePad]);

  const submitCautela = async () => {
    setIsSubmitting(true);
    try {
      // 1. Create Audit Header
      const { data: audit, error: auditError } = await supabase
        .from('cautelia_audits')
        .insert({
          user_id: String(user.registration || "").trim(),
          branch_id: user.branch_id || user.branch || user.filial || null,
          signature_url: signatures,
          type: 'checklist',
          status: 'confirmed'
        })
        .select()
        .maybeSingle();
      
      if (auditError) throw auditError;

      for (const item of items) {
        if (item.type === 'standard') {
          await supabase.from('cautelia_reports').update({ 
            status: item.status, 
            last_check: new Date().toISOString(),
            obs: item.obs
          }).eq('id', item.db_id);
        } else {
          // For big tools, if we came from transactions, we might need an upsert instead of update if row doesn't exist
          await supabase.from('cautelas').upsert({ 
            user_id: String(user.registration || "").trim(),
            tool_id: item.tool_id,
            status: item.status, 
            last_check: new Date().toISOString(),
            obs: item.obs
          }, { onConflict: 'user_id, tool_id' });
        }

        // Add to audit items for history
        await supabase.from('cautelia_audit_items').insert({
          audit_id: audit.id,
          tool_id: item.type === 'standard' ? item.tool_id : null,
          stock_tool_id: item.type === 'big' ? item.tool_id : null,
          status: item.status,
          obs: item.obs || ''
        });
      }

      setHasNotifiedWarning(false);
      confetti();
      setIsSuccess(true);
      setTimeout(() => {
        setIsSuccess(false);
        onBack();
      }, 3000);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 100 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex-1 flex flex-col bg-white rounded-[2rem] shadow-xl overflow-hidden"
    >
      <div className="p-6 bg-amber-500 text-white flex items-center justify-between">
        <button onClick={onBack} className="p-2"><X size={20} /></button>
        <h2 className="font-black italic uppercase tracking-tight">MINHA CAUTELIA</h2>
        <div className="w-10 h-10" />
      </div>

      <div className="p-6 flex-1 overflow-y-auto space-y-6 custom-scrollbar relative">
        <AnimatePresence>
          {isSuccess && (
            <motion.div 
              key="success-overlay"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 z-[200] bg-white flex flex-col items-center justify-center text-center p-8 gap-6"
            >
               <motion.div 
                 initial={{ scale: 0.5, rotate: -20 }}
                 animate={{ scale: 1, rotate: 0 }}
                 className="w-24 h-24 bg-emerald-100 text-emerald-600 rounded-[2.5rem] flex items-center justify-center shadow-xl shadow-emerald-100"
               >
                  <CheckCircle2 size={48} />
               </motion.div>
               <div>
                  <h2 className="text-2xl font-black italic uppercase text-slate-900 leading-none">Cautelia Finalizada!</h2>
                  <p className="text-[10px] text-slate-400 font-bold uppercase mt-3 tracking-widest leading-relaxed">
                    Seus registros foram sincronizados com sucesso.<br/>Bom trabalho!
                  </p>
               </div>
               <div className="w-full max-w-[120px] h-1.5 bg-slate-100 rounded-full overflow-hidden mt-4">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: "100%" }}
                    transition={{ duration: 3 }}
                    className="h-full bg-emerald-500"
                  />
               </div>
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {showChangeWarning && (
             <motion.div 
               key="warning-modal"
               initial={{ opacity: 0, scale: 0.9 }}
               animate={{ opacity: 1, scale: 1 }}
               exit={{ opacity: 0, scale: 0.9 }}
               className="fixed inset-x-6 top-1/2 -translate-y-1/2 z-[150] animate-in fade-in zoom-in duration-300"
             >
                <div className="bg-slate-900 text-white p-8 rounded-[3rem] shadow-[0_32px_64px_rgba(0,0,0,0.5)] flex flex-col items-center text-center gap-6 border border-white/10 mx-auto max-w-sm">
                   <div className="w-16 h-16 bg-amber-500 rounded-full flex items-center justify-center text-slate-900 shadow-xl shadow-amber-500/20">
                      <AlertTriangle size={32} />
                   </div>
                   <div>
                      <h4 className="font-black italic uppercase tracking-tight text-lg leading-none">Registro de Alteração</h4>
                      <p className="text-[11px] text-slate-400 font-bold uppercase mt-3 leading-relaxed">
                        Esta alteração ficará registrada no histórico do Administrador e poderá exigir justificativa posterior.
                      </p>
                   </div>
                   <button 
                    onClick={() => setShowChangeWarning(false)}
                    className="w-full bg-white text-slate-900 py-5 rounded-2xl font-black text-xs uppercase italic active:scale-95 transition-all shadow-xl hover:bg-slate-50"
                   >
                     Entendido
                   </button>
                </div>
             </motion.div>
          )}
        </AnimatePresence>

        {loading ? (
          <div className="py-20 text-center uppercase font-black text-slate-300">Carregando lista...</div>
        ) : items.length === 0 ? (
          <div className="py-32 flex flex-col items-center justify-center text-center gap-4">
             <div className="w-20 h-20 bg-slate-50 rounded-[2.5rem] flex items-center justify-center text-slate-200">
                <ClipboardList size={40} />
             </div>
             <div>
                <p className="text-sm font-black text-slate-300 uppercase italic">Sem ferramentas Cauteladas</p>
                <p className="text-[9px] text-slate-400 font-bold uppercase mt-1">Você não possui itens sob sua responsabilidade no momento.</p>
             </div>
          </div>
        ) : (
          <>
            <div className="flex items-center justify-between mb-4 px-2">
               <div>
                  <h3 className="text-xs font-black text-slate-800 uppercase italic">Checklist</h3>
                  <p className="text-[9px] text-slate-400 font-bold uppercase">Avalie seus itens</p>
               </div>
            </div>

            {items.map(item => (
              <div key={item.id} className="p-5 bg-slate-50 rounded-3xl border border-slate-200 space-y-4">
                 <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center border border-slate-200">
                       <Zap size={20} className="text-amber-500" />
                    </div>
                    <div>
                       <p className="text-xs font-black uppercase italic leading-none">{item.name}</p>
                       <p className="text-[10px] text-slate-400 font-bold mt-1">PAT: {item.code}</p>
                    </div>
                 </div>

                 <div className="grid grid-cols-3 gap-2">
                    {['ok', 'missing', 'damaged'].map(st => (
                      <button 
                        key={st}
                        onClick={() => updateItemStatus(item.id, st)}
                        className={`py-3 rounded-xl border-2 text-[8px] font-black uppercase tracking-widest transition-all ${item.status === st ? (st === 'ok' ? 'bg-emerald-500 border-emerald-500 text-white' : 'bg-rose-500 border-rose-500 text-white') : 'bg-white border-slate-100 text-slate-400'}`}
                      >
                        {st === 'ok' ? 'OK' : st === 'missing' ? 'NÃO TENHO' : 'ESTRAGOU'}
                      </button>
                    ))}
                 </div>
              </div>
            ))}

            <div className="pt-6 space-y-4">
               <div className="text-center">
                  <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest leading-none">ASSINE DIGITALMENTE</h3>
                  <p className="text-[10px] text-slate-300 mt-2 font-bold uppercase">Declaro que as informações acima são verdadeiras.</p>
               </div>
               <div className="bg-slate-50 rounded-3xl border-2 border-slate-200 h-40 overflow-hidden relative">
                  <canvas ref={canvasRef} width={400} height={160} className="w-full h-full cursor-crosshair" />
                  <button onClick={clearSignature} className="absolute bottom-2 right-2 text-[8px] font-black uppercase text-slate-300 hover:text-rose-500">Limpar</button>
               </div>

               <button 
                onClick={submitCautela}
                disabled={isSubmitting}
                className="w-full bg-slate-900 text-white font-black italic py-5 rounded-[2rem] shadow-2xl flex items-center justify-center gap-3 active:scale-95 transition-all text-lg uppercase"
               >
                 {isSubmitting ? 'ENVIANDO...' : 'FINALIZAR CAUTELIA'}
               </button>
            </div>
          </>
        )}
      </div>
    </motion.div>
  );
}

function MenuButton({ label, icon: Icon, color, desc, onClick }: any) {
  return (
    <button 
      onClick={onClick}
      className={`relative p-6 rounded-[2rem] flex flex-col justify-between items-start text-left group overflow-hidden transition-all active:scale-[0.97] bg-white border border-slate-100 shadow-sm`}
    >
       <div className={`${color} p-4 rounded-2xl text-white mb-4 group-hover:scale-110 group-hover:rotate-6 transition-transform shadow-lg`}>
          <Icon size={32} />
       </div>
       <div>
         <h3 className="text-xl font-black italic uppercase tracking-tighter text-slate-800 leading-none">{label}</h3>
         <p className="text-xs text-slate-400 font-bold mt-2 leading-tight uppercase tracking-tighter ">{desc}</p>
       </div>
       <div className="absolute bottom-4 right-4 text-slate-100 scale-150 -rotate-12 group-hover:scale-[2] transition-transform">
          <Icon size={48} />
       </div>
    </button>
  );
}
