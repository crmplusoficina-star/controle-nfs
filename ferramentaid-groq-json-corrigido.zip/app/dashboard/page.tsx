'use client';

import React from 'react';
import { useAuth } from '@/lib/auth-context';
import { motion, AnimatePresence } from 'motion/react';
import { 
  FileText, 
  Package, 
  Zap, 
  UserCheck, 
  Plus,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';
import Link from 'next/link';
import { supabase } from '@/lib/supabase';

export default function DashboardPage() {
  const { user } = useAuth();
  const [activeCautelas, setActiveCautelas] = React.useState<any[]>([]);
  const [latestNF, setLatestNF] = React.useState<any>(null);
  const [upcomingPayments, setUpcomingPayments] = React.useState<any[]>([]);
  const [isLoading, setIsLoading] = React.useState(true);

  React.useEffect(() => {
    async function fetchDashboardData() {
      if (!user) return;
      setIsLoading(true);

      // Fetch active cautelas (joining with tools to get name/code)
      const { data: cautelasData } = await supabase
        .from('cautelas')
        .select(`
          id,
          status,
          tools (
            name,
            code
          )
        `)
        .eq('user_id', user.registration)
        .neq('status', 'ok') // Or whatever defines "active" or "problematic"
        .limit(2);
      
      if (cautelasData) setActiveCautelas(cautelasData);

      // Fetch latest pending invoice
      let nfQuery = supabase
        .from('nfs')
        .select('*')
        .eq('status', 'pending');
      
      if (user.role === 'Operador' && user.branch_id) {
        nfQuery = nfQuery.eq('branch_id', user.branch_id);
      }

      const { data: nfData } = await nfQuery
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();
      
      if (nfData) setLatestNF(nfData);

      // Fetch upcoming payments (next 3 days)
      const today = new Date();
      const threeDaysLater = new Date();
      threeDaysLater.setDate(today.getDate() + 3);

      const { data: paymentsData } = await supabase
        .from('nfs')
        .select('*')
        .eq('status', 'pending')
        .gte('payment_date', today.toISOString().split('T')[0])
        .lte('payment_date', threeDaysLater.toISOString().split('T')[0])
        .order('payment_date', { ascending: true });
      
      if (paymentsData) setUpcomingPayments(paymentsData);

      setIsLoading(false);
    }
    fetchDashboardData();
  }, [user]);

  const kahootActions = [
    { 
      id: 'loan', 
      name: 'EMPRÉSTIMO', 
      desc: 'Scanear Ferramenta', 
      icon: Plus, 
      color: 'bg-blue-600 hover:bg-blue-500', 
      path: '/dashboard/ferramentaria',
      number: '01'
    },
    { 
      id: 'cautelia', 
      name: 'CAUTELIA', 
      desc: 'Assinatura Digital', 
      icon: ShieldCheck, 
      color: 'bg-emerald-500 hover:bg-emerald-400', 
      path: '/dashboard/cautelia',
      number: '02'
    },
    { 
      id: 'stock', 
      name: 'MEU ESTOQUE', 
      desc: 'Consultar Retiradas', 
      icon: Package, 
      color: 'bg-amber-500 hover:bg-amber-400', 
      path: '/dashboard/stock',
      number: '03'
    },
    { 
      id: 'profile', 
      name: 'MEU PERFIL', 
      desc: 'Dados da Matrícula', 
      icon: UserCheck, 
      color: 'bg-indigo-500 hover:bg-indigo-400', 
      path: '/dashboard/profile',
      number: '04'
    },
  ];

  return (
    <div className="p-0 space-y-6">
      <header className="mb-8 flex items-start justify-between">
        <div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tight italic">
            Olá, {user?.name?.split(' ')?.[0] || 'Usuário'}!
          </h1>
          <p className="text-slate-500 mt-1 font-medium italic opacity-80 uppercase text-xs tracking-widest">
            O que vamos operacionalizar agora?
          </p>
        </div>

        {/* Payment Alerts */}
        <AnimatePresence>
          {upcomingPayments.length > 0 && (
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-rose-50 border border-rose-200 rounded-2xl p-4 flex items-center gap-4 shadow-sm"
            >
              <div className="w-10 h-10 bg-rose-500 rounded-full flex items-center justify-center text-white shrink-0">
                <Zap size={20} fill="white" />
              </div>
              <div>
                <p className="text-[10px] font-black uppercase tracking-tight text-rose-600 leading-none">Alerta de Vencimento</p>
                <p className="text-xs font-bold text-slate-700 mt-1">
                  {upcomingPayments.length} {upcomingPayments.length === 1 ? 'nota vence' : 'notas vencem'} em breve!
                </p>
              </div>
              <Link href="/dashboard/nfs?tab=pending" className="ml-2 p-2 bg-rose-100 hover:bg-rose-200 rounded-xl transition-colors">
                <ArrowRight size={16} className="text-rose-600" />
              </Link>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      <div className="grid grid-cols-12 gap-8">
        {/* Large Action Buttons (Kahoot Style) */}
        <div className="col-span-12 lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 gap-6">
          {kahootActions.map((action, i) => (
            <Link key={action.id} href={action.path} className="group">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ y: -6 }}
                whileTap={{ scale: 0.98 }}
                className={`relative h-64 ${action.color} cursor-pointer rounded-3xl p-8 shadow-xl flex flex-col items-center justify-center text-white transition-all overflow-hidden`}
              >
                <div className="w-20 h-20 bg-white/20 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-white/30 transition-colors">
                  <action.icon size={44} strokeWidth={2.5} />
                </div>
                <h3 className="text-2xl font-black italic tracking-tight">{action.name}</h3>
                <p className="text-white/80 font-bold text-[10px] mt-2 uppercase tracking-[0.2em]">{action.desc}</p>
                <div className="absolute bottom-4 right-6 text-7xl font-black text-white/10 pointer-events-none">
                  {action.number}
                </div>
              </motion.div>
            </Link>
          ))}
        </div>

        {/* Right Column: Quick Status / NF Preview */}
        <div className="col-span-12 lg:col-span-4 flex flex-col gap-8">
          {/* Active Cautelas Card */}
          <div className="bg-white rounded-[2rem] p-8 shadow-xl border border-slate-200">
            <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-6">Minhas Cautelas Ativas</h4>
            <div className="space-y-4">
              {isLoading ? (
                <div className="py-4 text-[10px] font-black uppercase tracking-widest text-slate-300 animate-pulse">Consultando Cautelas...</div>
              ) : activeCautelas.length === 0 ? (
                <div className="py-4 text-[10px] font-bold text-slate-400 italic">Nenhuma cautela pendente. ✅</div>
              ) : activeCautelas.map((c) => (
                <div key={c.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border-l-[6px] border-blue-500 shadow-sm transition-hover hover:shadow-md cursor-default">
                  <div>
                    <p className="text-xs font-black text-slate-800">{c.tools?.name}</p>
                    <p className="text-[10px] text-slate-400 uppercase font-mono mt-1">Cod: {c.tools?.code}</p>
                  </div>
                  <span className={`text-[10px] font-black px-2 py-1 rounded ${c.status === 'missing' ? 'bg-rose-50 text-rose-600' : 'bg-amber-50 text-amber-600'}`}>
                    {c.status.toUpperCase()}
                  </span>
                </div>
              ))}
            </div>
            <Link href="/dashboard/cautelia" className="mt-6 flex items-center justify-center gap-2 text-[10px] font-black text-indigo-600 uppercase tracking-widest hover:underline group">
              Ver Histórico Completo
              <ArrowRight size={12} className="group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>

          {/* NF Pendente (IA Scan) */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-indigo-950 rounded-[2rem] p-8 shadow-2xl text-white flex-1 relative overflow-hidden group min-h-[350px] flex flex-col"
          >
            <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
              <Zap size={100} />
            </div>
            
            <div className="flex items-center justify-between mb-8">
              <h4 className="text-[10px] font-black uppercase tracking-widest text-indigo-400">Última NF Pendente</h4>
              {latestNF && <span className="bg-rose-500 text-[10px] font-black px-3 py-1 rounded-full animate-pulse shadow-lg uppercase tracking-wider">Aguardando</span>}
            </div>
            
            {isLoading ? (
               <div className="flex-1 flex items-center justify-center text-xs font-black uppercase tracking-[0.2em] text-indigo-400 animate-pulse italic">
                 Sincronizando NF...
               </div>
            ) : latestNF ? (
              <>
                <div className="bg-white/10 backdrop-blur-md rounded-2xl p-5 mb-6 border border-white/10 ring-1 ring-white/5">
                  <p className="text-[9px] text-indigo-300 uppercase mb-1 font-bold tracking-wider">Fornecedor</p>
                  <p className="text-base font-black italic">{latestNF.supplier}</p>
                </div>
                
                <div className="grid grid-cols-2 gap-4 mb-8">
                  <div className="bg-white/5 border border-white/5 p-4 rounded-2xl backdrop-blur-sm">
                    <p className="text-[9px] text-indigo-400 uppercase font-black mb-1">Valor</p>
                    <p className="text-sm font-black">R$ {latestNF.amount?.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</p>
                  </div>
                  <div className="bg-white/5 border border-white/5 p-4 rounded-2xl backdrop-blur-sm">
                    <p className="text-[9px] text-indigo-400 uppercase font-black mb-1">Emissão</p>
                    <p className="text-sm font-black">{latestNF.date ? new Date(latestNF.date).toLocaleDateString('pt-BR') : '-'}</p>
                  </div>
                </div>
                
                <Link href="/dashboard/nfs" className="block mt-auto">
                  <button className="w-full py-4 bg-indigo-400 hover:bg-indigo-300 active:scale-95 rounded-[1.25rem] text-indigo-950 font-black text-xs uppercase tracking-tighter shadow-xl transition-all">
                    Visualizar no Controle
                  </button>
                </Link>
              </>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-center">
                <FileText className="text-indigo-800 mb-4" size={48} />
                <p className="text-xs font-black uppercase tracking-widest text-indigo-400 italic">Nenhum registro<br/>pendente agora</p>
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
}
