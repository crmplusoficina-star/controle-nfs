'use client';

import React, { useState, useEffect } from 'react';
import { useAuth } from '@/lib/auth-context';
import { motion } from 'motion/react';
import { ShieldCheck, LogIn, Zap } from 'lucide-react';
import { useRouter } from 'next/navigation';

export default function LoginPage() {
  const [matricula, setMatricula] = useState('');
  const { login, user, isLoading } = useAuth();
  const [isError, setIsError] = useState(false);
  const router = useRouter();

  useEffect(() => {
    if (user) {
      router.push('/dashboard');
    }
  }, [user, router]);

  if (isLoading) return null;

  if (user) {
    return <DashboardRedirect />;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsError(false);
    const trimmedMatricula = matricula.trim();
    if (trimmedMatricula.length > 3) {
      const success = await login(trimmedMatricula);
      if (!success) {
        setIsError(true);
      }
    } else {
      setIsError(true);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-indigo-950 relative overflow-hidden">
      {/* Decorative background elements */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-indigo-500/10 rounded-full blur-[100px] -mr-64 -mt-64" />
      <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-rose-500/5 rounded-full blur-[100px] -ml-64 -mb-64" />
      
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md bg-white rounded-[2.5rem] shadow-2xl overflow-hidden relative z-10 p-1 bg-gradient-to-br from-white to-slate-100"
      >
        <div className="p-8 pb-4 text-center">
          <div className="mb-6">
            <h1 className="text-3xl font-black tracking-tighter text-indigo-950">
              FERRAMENT<span className="text-indigo-400 italic">ARIA</span>
            </h1>
            <p className="text-[10px] uppercase tracking-[0.3em] font-black text-slate-400 mt-1">Sistema de controle de NFS</p>
          </div>
          <div className="inline-flex items-center justify-center p-4 bg-indigo-50 text-indigo-600 rounded-3xl mb-8 ring-4 ring-indigo-50/50">
            <Zap size={40} className="fill-indigo-600" />
          </div>
          <h2 className="text-xl font-black text-slate-800 italic">Login do Colaborador</h2>
          <p className="text-slate-500 text-sm mt-1 font-medium">Informe sua matrícula operacional</p>
        </div>
        
        <div className="p-8 pt-4">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <div className="relative">
                <input
                  id="matricula"
                  type="text"
                  value={matricula}
                  onChange={(e) => {
                    setMatricula(e.target.value);
                    setIsError(false);
                  }}
                  className={`w-full px-6 py-4 bg-slate-50 border-2 rounded-2xl focus:ring-4 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all text-xl font-mono text-center tracking-widest ${isError ? 'border-rose-400 ring-rose-100' : 'border-slate-100'}`}
                  placeholder="000000"
                />
              </div>
              {isError && (
                <p className="text-rose-500 text-[10px] mt-2 text-center uppercase font-black tracking-widest">Matrícula inválida ou não encontrada</p>
              )}
            </div>

            <button
              type="submit"
              className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-black py-4 px-6 rounded-2xl shadow-xl shadow-indigo-600/20 flex items-center justify-center gap-3 transition-all active:scale-95 text-sm uppercase tracking-widest"
            >
              <LogIn size={18} />
              Entrar no Sistema
            </button>
          </form>

          <div className="mt-8 pt-6 border-t border-slate-100 flex items-center justify-center gap-2 text-slate-400 text-[10px] font-black uppercase tracking-widest">
            <ShieldCheck size={14} className="text-emerald-500" />
            <span>Conexão Segura AES-256</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

function DashboardRedirect() {
  const router = useRouter();
  
  useEffect(() => {
    router.push('/dashboard');
  }, [router]);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-indigo-950">
       <motion.div
        animate={{ 
          scale: [1, 1.2, 1],
          rotate: [0, 180, 360]
        }}
        transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
        className="text-indigo-400 mb-8"
       >
         <Zap size={64} fill="currentColor" />
       </motion.div>
       <p className="text-white font-black italic uppercase tracking-widest text-xs animate-pulse">Iniciando Ambiente...</p>
    </div>
  );
}
